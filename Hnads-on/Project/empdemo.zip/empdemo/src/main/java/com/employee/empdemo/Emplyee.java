package com.employee.empdemo;

import jakarta.persistence.*;

@Entity
@Table(name="emp1")

public class Emplyee 
{
    @Id
    @Column(name="id")
    private int id;
    
    @Column(name="emp_name")
    private String name;
      
    private EmpDetail e1;
     
	public EmpDetail getE1() {
		return e1;
	}

	public void setE1(EmpDetail e1) {
		this.e1 = e1;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	  @Override
	    public String toString() {
	        return this.id+ ":"+this.name;
}
}
