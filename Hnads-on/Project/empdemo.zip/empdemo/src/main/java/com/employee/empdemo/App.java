package com.employee.empdemo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
    	 // Create Configuration
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");
        configuration.addAnnotatedClass(Emplyee.class);
 
        // Create Session Factory
        SessionFactory sessionFactory = configuration.buildSessionFactory();
 
        // Initialize Session Object
        Session session = sessionFactory.openSession();
 
        Emplyee ee = new Emplyee();
          ee.setId(1);
          ee.setName("adi");
          
          EmpDetail e1=new EmpDetail();
          e1.setAge(34);
          e1.setGender("male");
         ee.setE1(e1);
          
          session.beginTransaction();
          
          // Here we have used
          // save() method of JPA
          session.save(ee);
   
          session.getTransaction().commit();
    }
}
