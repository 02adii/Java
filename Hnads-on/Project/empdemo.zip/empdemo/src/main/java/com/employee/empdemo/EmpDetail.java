package com.employee.empdemo;

import jakarta.persistence.*;
@Embeddable
public class EmpDetail {
     
     public EmpDetail(int age, String gender) {
		super();
		this.age = age;
		this.gender = gender;
     }
	public EmpDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Column(name="age")
     private int age;
     
     @Column(name="gender")
     private String gender;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

  
}
