package com.course;



import java.util.ArrayList;
import java.util.List;

import com.doa.CourseDao;
import com.doa.InstructorDao;
import com.entity.Course;
import com.entity.Instructor;
import com.entity.InstructorDetail;

public class App 
{
    public static void main( String[] args )
    {
        // Save two instructors
        Instructor instructor = new Instructor("Amit", "Varma", "amitv45@gmail.com");
        InstructorDetail instructorDetail = new InstructorDetail("http://www.youtube.com", "Piano");
        instructorDetail.setInstructor(instructor);
        instructor.setInstructorDetail(instructorDetail);
       
        Instructor instructor1 = new Instructor("Shree", "Kumar", "shreekumar@gmail.com");
        InstructorDetail instructorDetail1 = new InstructorDetail("http://www.youtube.com", "Guitar");
        instructorDetail1.setInstructor(instructor1);
        instructor1.setInstructorDetail(instructorDetail1);
       
         List<Course> courses=new ArrayList<>();
         //create some courses
         Course co=new Course("btech");
         co.setInstructor(instructor);
         courses.add(co);
         CourseDao cod=new CourseDao();
         cod.saveCourse(co);
         
         
    }
}
