package com.student.service;

import com.student.entity.Address;
import com.student.model.AddressDTO;


public interface AddressService {

	String createAddress(Address address);
	AddressDTO updateAddress(int id, Address address);
	AddressDTO getAddressById(int id);
}
