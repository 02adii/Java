package com.student.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class adminDTO extends UserDTO {

	private String name;
	private String email;
}
