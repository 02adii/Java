/*
 * package com.hotel.dto;
 * 
 * //import java.util.Date;
 * 
 * import lombok.Getter; import lombok.Setter;
 * 
 * @Getter
 * 
 * @Setter public class PaymentDetailsDto { public String paymentdate; public
 * String customername; public int roomno; public int totalamount; public String
 * facility; }
 */