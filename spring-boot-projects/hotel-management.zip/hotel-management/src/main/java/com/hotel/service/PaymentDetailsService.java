/*
 * package com.hotel.service;
 * 
 * import java.util.List;
 * 
 * import com.hotel.dto.PaymentDetailsDto; import
 * com.hotel.entity.PaymentDetails;
 * 
 * public interface PaymentDetailsService { public String
 * createPaymentDetails(PaymentDetails paymentdetails);
 * 
 * public PaymentDetailsDto updatePaymentDetails(int pid, PaymentDetails
 * paymentdetails);
 * 
 * public PaymentDetailsDto getPaymentDetailsById(int pid);
 * 
 * List<PaymentDetailsDto> getAllCustomers();
 * 
 * String deletePaymentDetailsById(int pid);
 * 
 * void deleteAllPayments(); }
 */